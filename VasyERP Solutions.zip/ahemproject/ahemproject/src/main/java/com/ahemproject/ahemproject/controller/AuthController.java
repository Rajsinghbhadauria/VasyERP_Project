package com.ahemproject.ahemproject.controller;

import com.ahemproject.ahemproject.service.AuthService;
import com.ahemproject.ahemproject.service.LoginAttemptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@RestController
public class AuthController {

    @Autowired
    private AuthService authService;

    @Autowired
    private LoginAttemptService loginAttemptService;

    @PostMapping("/login")
    public Map<String, String> login(@RequestParam String username, @RequestParam String password) {
        Map<String, String> response = new HashMap<>();

        if (loginAttemptService.isBlocked(username)) {
            long remainingTime = loginAttemptService.getRemainingLockTime(username);
            long minutes = TimeUnit.MILLISECONDS.toMinutes(remainingTime);
            response.put("error", "Account locked. Try again in " + minutes + " minutes.");
            return response;
        }

        try {
            Authentication auth = authService.authenticate(username, password);
            loginAttemptService.loginSucceeded(username);
            response.put("message", "Login successful");
        } catch (BadCredentialsException e) {
            loginAttemptService.loginFailed(username);

            if (loginAttemptService.isBlocked(username)) {
                long remainingTime = loginAttemptService.getRemainingLockTime(username);
                long minutes = TimeUnit.MILLISECONDS.toMinutes(remainingTime);
                response.put("error", "Account locked due to too many failed attempts. Try again in " + minutes + " minutes.");
            } else {
                response.put("error", "Invalid credentials");
            }
        }
        return response;
    }
}