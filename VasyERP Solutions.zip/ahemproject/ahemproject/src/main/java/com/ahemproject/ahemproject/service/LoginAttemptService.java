package com.ahemproject.ahemproject.service;

import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Service
public class LoginAttemptService {

    private final Map<String, Integer> attemptsCache = new HashMap<>();
    private final Map<String, Long> lockTimeCache = new HashMap<>();
    private final int MAX_ATTEMPT = 5;
    private final long COOLDOWN_PERIOD = TimeUnit.MINUTES.toMillis(30);

    public void loginFailed(String key) {
        int attempts = attemptsCache.getOrDefault(key, 0) + 1;
        attemptsCache.put(key, attempts);

        if (attempts >= MAX_ATTEMPT) {
            lockTimeCache.put(key, System.currentTimeMillis());
        }
    }

    public void loginSucceeded(String key) {
        attemptsCache.remove(key);
        lockTimeCache.remove(key);
    }

    public boolean isBlocked(String key) {
        if (!lockTimeCache.containsKey(key)) return false;

        long lockTime = lockTimeCache.get(key);
        if (System.currentTimeMillis() - lockTime > COOLDOWN_PERIOD) {
            lockTimeCache.remove(key);
            attemptsCache.remove(key);
            return false;
        }
        return true;
    }

    public long getRemainingLockTime(String key) {
        if (!isBlocked(key)) return 0;
        long elapsedTime = System.currentTimeMillis() - lockTimeCache.get(key);
        return COOLDOWN_PERIOD - elapsedTime;
    }
}